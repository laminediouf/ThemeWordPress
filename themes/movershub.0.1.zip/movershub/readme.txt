﻿=================
Movershub THEME
=================
Contributors: Themeicy
Tags: three-columns, left-sidebar, right-sidebar, custom-colors, custom-logo, featured-images, full-width-template, threaded-comments, blog, e-commerce, entertainment, food-and-drink, news
Requires at least: 4.0.5
Tested up to: 4.9.5
Stable tag: 0.1

== Theme License & Copyright ==
Movershub is distributed under the terms of the GNU GPL
Movershub -Copyright 2018 Movershub, themeicy.com

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

=================
SHORT DESCRIPTION
=================
Movershub is a powerful bootstrap Wordpress theme for spa or individuals. Movershub theme which can be used for web design firms or any other transport, woocommerce and any other kind of website purpose. It comes with all features these kind of shop page, blog page, Contact form seven working, custom logo, slides variation, color pallate


===========
ABOUT THEME
=========== 
Theme has two, three, four footer layout feature.We focused on usability across various
devices, starting with smart phones.it is compatible with various devices. Movershub is a
Cross-Browser Compatible theme that works on All leading web browsers. Movershub is easy to use and 
user friendly theme. Movershub has boxed and full-width layout feature.
Powerful but simple Movershub theme content customized through customizer. to make your site attractive it has two 
widget sections first for “sidebar widget section” and second for “Footer widget section” . 

To make your website in two column use sidebar widget section. to set custom menu in header set primary location. we added social media links to added your social links.It boasts of beautifully designed page sections , Home, Blog and Default Page Template(page with right sidebar), Page Full-Width, Page Left Sidebar. Movershub theme has more advanced feature to make your site awesome like: it has header top bar dark & lite color feature. you can also changed header color dark and lite styling. Theme compatible with woocommerce. Movershub is a fully woocommerce tested theme. Movershub is translation ready theme with WPML compatible & Many More….

This theme is compatible with Wordpress Version 4.4.2  and above and it supports the new theme customization API (https://codex.wordpress.org/Theme_Customization_API).

Supported browsers: Firefox, Opera, Chrome, Safari and IE10+ (Some css3 styles like shadows, rounder corners and 2D transform are not supported by IE8 and below).

/***** BUNDELED CSS ***/
============================================
This theme uses Underscores
============================================
 * Movershub is based on Underscores. All the files in the theme package are from Underscores, unless stated otherwise.
 * Copyright: Automattic, automattic.com
 * Source: http://underscores.me/
 * License: GPLv2
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html

/**** Images Source *****/
============================================
***** Screenshot bredcrumb Image CCO by Pexels  *****/
1. https://pixabay.com/en/business-cargo-containers-crate-1845350/

***** Screenshot slider Image CCO McKylan Mullins *****/
2. https://www.pexels.com/photo/man-wearing-black-columbia-zip-up-jacket-1047958/

========================================================================================	
--- Version 0.1 ----
1. Relesed
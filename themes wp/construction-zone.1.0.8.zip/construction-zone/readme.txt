=== construction zone ===

Contributors: dazzlersoft
Requires at least: 4.0
Tested up to: 4.9.5
Stable tag: 1.0.8
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

construction zone WordPress Theme, Copyright (C) 2018, dazzlersoft
construction zone is distributed under the terms of the GNU General Public License v2

Business WordPress Theme

== Description ==

Construction zone is a free construction wordpress. Theme has  responsive design made with bootstrap, retina ready blog layout enable and with sidebar. Construction zone comes with  full screen slider, high quality Home Page including  gallery or portfolio section, testimonial section, service section, team section, recent post section & client logo section. Construction zone fully customizable  built on wordpress customizer that enable you to configure your website in live preview. Theme is SEO friendly, Cross browser compatible And compatible with all major plugins.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Changelog ==

= 1.0.8 =
* resolved minor issue

= 1.0.7 =
* resolved esc_html issue.
* resolved wp_bootstrap_navwalke Licence is missing.

= 1.0.5 =
* resolved Escaping are not properly doing issue.

= 1.0.4 =
* Updated License Definition
* Resolved on-minified Version issue.

= 1.0.2 =
* Resolved Validate and/or sanitize.
* Resolved 404 page related issue

= 1.0.1 =
* Initial release

== Some links ==

News & Updates @ http://dazzlersoftware.com/blog/

== Credits ==

* Based on Underscores http://underscores.me/, (C) 2012-2016 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* Bootstrap js css - v3.3.6 (http://getbootstrap.com)Copyright 2011-2015 Twitter, Inc.Licensed under the MIT license
* Font Awesome css : http://fontawesome.io/, (c) Dave Gandy, CSS - [MIT](http://opensource.org/licenses/MIT) ; Fonts - [SIL OFL 1.1](http://scripts.sil.org/OFL)
* Query Nivo Slider css : v3.2 Copyright 2012, Dev7studios  Free to use and abuse under the MIT license.


* WOW wow.js - v1.3.0 - 2016-10-04 https://wowjs.uk  Copyright (c) 2016 Thomas Grainger; Licensed MIT 
* scrollup js v2.4.1 : Copyright (c) Mark Goodyear � @markgdyr � http://markgoodyear.com Url: http://markgoodyear.com/labs/scrollup/
* jQuery meanMenu & css v2.0.8 v1.0.4 @Copyright (C) 2012-2014 Chris Wharton @ MeanThemes (https://github.com/meanthemes/meanMenu)


== Images Used ==
License: [CC0](https://creativecommons.org/publicdomain/zero/1.0/deed.en)

	= Screenshot =
	Source : https://www.pexels.com/photo/group-of-persons-wearing-yellow-safety-helmet-during-daytime-33266/
	
	= header banner =
	Source : https://www.pexels.com/photo/group-of-persons-wearing-yellow-safety-helmet-during-daytime-33266/


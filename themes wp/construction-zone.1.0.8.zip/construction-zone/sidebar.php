
<?php if (is_active_sidebar('construction_zone_blog_sidebar')) 
      { ?>
	    <?php dynamic_sidebar('construction_zone_blog_sidebar'); ?>
<?php } ?>

<?php 
// For Search Results
?>

<div class="inner-news-box-bottom">
	<h4><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h4>
</div>							

							
							
							
							
							
							
							

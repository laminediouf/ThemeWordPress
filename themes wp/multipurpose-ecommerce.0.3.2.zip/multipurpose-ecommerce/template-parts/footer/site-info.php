<?php
/**
 * Displays footer site info
 */

?>
<div class="site-info">
	<p><?php echo esc_html(get_theme_mod('multipurpose_ecommerce_footer_text',__('Design & Developed By','multipurpose-ecommerce'))); ?> <?php multipurpose_ecommerce_credit(); ?></p>
</div>
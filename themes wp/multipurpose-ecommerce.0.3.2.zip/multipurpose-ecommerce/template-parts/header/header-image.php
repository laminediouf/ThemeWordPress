<?php
/**
 * Displays header media
 */

?>
<div class="custom-header">

	<?php get_template_part( 'template-parts/header/site', 'branding' ); ?>

</div>
